Test File
/*main functionm*/

struct Node{
	auto val;
};

int main()
{
	struct Node *test;
	test->val=16;
	test->val++;
	__Bool bool_var = TRUE;
	auto x=9/2;
	float f = 1.2;
	f = f<<1;
	f = f>>1;
	char c = 'z';
	short si = 12;
	enum week{Jan, Feb};
	extern ex=128;
	restrict s;
	register unsigned int ui=128;
	(void*) vptr;
	for(int static unsigned int i=0;i<=128;i+=1)
	{
		if(f==1.2)
		{
			break;
		}
		else
		{
			double ret = f*0.6;
			continue;
		}
	}

	return 0;
} 