#ifndef TOYLIB_H
#define TOYLIB_H
#define BAD -1
#define GOOD 1
int printStringUpper (char *);
int printHexInteger (int);
int printFloat (float);
int readHexInteger (int *);
int readFloat (float *);
#endif